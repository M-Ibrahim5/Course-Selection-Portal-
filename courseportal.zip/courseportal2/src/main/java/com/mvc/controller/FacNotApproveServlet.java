package com.mvc.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.FacManageDao;


public class FacNotApproveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public FacNotApproveServlet() {

    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FacManageDao FacManageDAO = new FacManageDao();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String coursename = request.getParameter("coursename");
		String stuusername = request.getParameter("stuusername");
		
		try {
			request.setAttribute("username", username); 
            request.setAttribute("password", password);
			boolean deleteStu = FacManageDAO.deleteApply(stuusername,coursename);
            RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/FacManageStuBridgeServlet");
            dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
