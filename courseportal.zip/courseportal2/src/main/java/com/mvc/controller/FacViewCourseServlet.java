package com.mvc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CoursesBean;
import com.mvc.dao.FacManageDao;

/**
 * Servlet implementation class facManageServlet
 */

public class FacViewCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private FacManageDao FacManageDAO;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() {
		FacManageDAO = new FacManageDao(); 
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		                                                                 		
			String value = request.getParameter("username");
			String value1 = request.getParameter("password");
            request.setAttribute("username", value); 
            request.setAttribute("password", value1); 
			List<CoursesBean> listCourse = FacManageDAO.selectAllCourses(value);
			request.setAttribute("listCourses", listCourse);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/facultyManageCourse.jsp");
			dispatcher.forward(request, response);
	}


}



/* 
 * public List<CustomerBean> selectAllCustomer4 () {
		List<CustomerBean> allCustomer4 = new ArrayList<>();
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try {
				pstmt = con.prepareStatement("SELECT * FROM customer");
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String id = rs.getString("id");
					String username = rs.getString("username");
					String email = rs.getString("email");
					String address = rs.getString("address");
					String phone = rs.getString("phone");
					String password = rs.getString("password");
					String age = rs.getString("age");
					allCustomer4.add(new CustomerBean(id,username,email,address,phone,password,age));
				}
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<CustomerBean>();
			}
		}
		System.out.println("No Connection...");
		return allCustomer4;
	}
 */