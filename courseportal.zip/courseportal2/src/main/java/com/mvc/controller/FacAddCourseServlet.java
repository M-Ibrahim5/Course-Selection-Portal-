package com.mvc.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mvc.bean.CoursesBean;
import com.mvc.dao.FacManageDao;



public class FacAddCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FacManageDao FacManageDAO;  

	public void init() {
		 FacManageDAO = new FacManageDao(); 
	}
    public FacAddCourseServlet() {

    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String courseId =  request.getParameter("courseid");
			String courseName = request.getParameter("coursename");
			String facultyId = request.getParameter("facultyid");
			String courseLevel = request.getParameter("courselevel");
			String cpassword = request.getParameter("cpassword");
			//String userType = request.getParameter("usertype");
			
            
			CoursesBean newCourse = new CoursesBean(courseId,courseName,courseLevel,facultyId,cpassword);
			
	        String courseRegistered = FacManageDAO.addCourse(newCourse);
	        
	        if(courseRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
	        {
	        	request.setAttribute("username", username); 
	            request.setAttribute("password", password);
	           request.getRequestDispatcher("/FacViewCourseServlet").forward(request, response);
	        }
	        else   //On Failure, display a meaningful message to the User.
	        {
	        	request.setAttribute("username", username); 
	            request.setAttribute("password", password);
	           request.setAttribute("errMessage", courseRegistered);
	           request.getRequestDispatcher("/facAddCourse.jsp").forward(request, response);
	        }



	}
}
