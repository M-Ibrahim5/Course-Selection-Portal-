package com.mvc.controller;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mvc.bean.CoursesBean;
import com.mvc.dao.CourseManageDao;


public class CourseViewDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    private CourseManageDao CourseManageDAO;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() {
		CourseManageDAO = new CourseManageDao(); 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String value = request.getParameter("username");
		String value1 = request.getParameter("password");
        request.setAttribute("username", value); 
        request.setAttribute("password", value1); 
		List<CoursesBean> courseDetail = CourseManageDAO.selectAllCourses(value);
		request.setAttribute("courseDetail", courseDetail);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/courseEditDetail.jsp");
		dispatcher.forward(request, response);
	}

}
