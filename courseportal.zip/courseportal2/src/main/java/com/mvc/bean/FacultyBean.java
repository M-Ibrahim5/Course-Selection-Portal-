package com.mvc.bean;

public class FacultyBean {

	
	private String facultyName;
	private String facultyid;
	
	
	
	public FacultyBean() {
	}

	public FacultyBean(String facultyName) {
		this.facultyName = facultyName;
	}


	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}


	public String getFacultyid() {
		return facultyid;
	}


	public void setFacultyid(String facultyid) {
		this.facultyid = facultyid;
	}
	
	
	
	
}
